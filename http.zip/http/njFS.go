package main

import (
	"fmt"
	"html/template"
	"io"
	"io/ioutil"
	"net/http"
	"os"

	"gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
)

type File struct {
	Title   string
	Content []byte
}

func (f *File) fopen() error {
	filename := f.Title + ".txt"
	return ioutil.WriteFile(filename, f.Content, 0600)
}
func fread(file string) (*File, error) {
	f := file + ".txt"
	content, _ := ioutil.ReadFile(f)
	return &File{Title: f, Content: content}, nil
}

//string function overrriding
func String(b interface{}) string {
	return fmt.Sprintf("\n%s\n", b)
}
func indexHandler(res http.ResponseWriter, req *http.Request) {
	//r := req.URL.Path[len("/login/"):]
	v, _ := template.ParseFiles("index.html")
	v.Execute(res, nil)
}
func viewHandler(res http.ResponseWriter, req *http.Request) {
	//reqVal := req.URL.Path[len("/view/"):]
	//outSource, _ := fread(reqVal)
	res.Header().Set("Access-Control-Allow-Origin", "*")
	fmt.Fprint(res, "heolllo")
}
func EditHandler(res http.ResponseWriter, req *http.Request) {
	r := req.URL.Path[len("/edit/"):]
	s, _ := fread(r)
	v, _ := template.ParseFiles("http.html")
	v.Execute(res, s)
}
func loginHandler(res http.ResponseWriter, req *http.Request) {
	//r := req.URL.Path[len("/login/"):]
	res.Header().Set("Access-Control-Allow-Origin", "*")
	v, _ := template.ParseFiles("login.html")

	v.Execute(res, nil)
}
func saveHandler(res http.ResponseWriter, req *http.Request) {
	r := req.URL.Path[len("/save/"):]
	fname := req.FormValue("fname")
	sname := req.FormValue("sname")
	email := req.FormValue("email")
	pass := req.FormValue("pass")
	file, _, err := req.FormFile("image")
	if err != nil {
		panic("----------:-(--Error in Uploading-----------------:-(--------")
	} else {
		fmt.Println("------------------------>file converted to bytes Successfully<----------------------")
	}
	fpath, err2 := os.OpenFile("./a/profiles/"+email+".jpg", os.O_WRONLY|os.O_CREATE, 0666)
	io.Copy(fpath, file)
	if err2 != nil {
		fmt.Println(err)
		return
	}
	session, err3 := mgo.Dial("127.0.0.1:27017")
	session.SetMode(mgo.Monotonic, true)
	if err3 != nil {
		panic("----------:-(--Error in connecting databases------------------:-(--------")
	} else {
		fmt.Println("------------------------>Database is connected<----------------------")
	}
	c := session.DB("school1").C("student2")
	mapDoc := map[string]interface{}{"fname": fname, "sname": sname, "email": email, "dp": "/a/profiles/" + email + ".jpg", "pass": pass}
	err = c.Insert(mapDoc)
	if err != nil {
		panic("Error in Inserting datas in the Collection")
	} else {
		fmt.Println("Inserted")
	}
	//.res["fname"] = fname
	fmt.Println(r, fname, sname, email, pass)
	t, _ := template.ParseFiles("njSuccess.html")
	t.Execute(res, mapDoc)

}
func homeHandler(r http.ResponseWriter, req *http.Request) {
	type User struct {
		Fname string `bson:"fname"`
		Sname string `bson:"sname"`
		Email string `bson:"email"`
		Pass  string `bson:"pass"`
		Dp    string `bson:"dp"`
	}
	user := User{}
	email := req.FormValue("email")
	password := req.FormValue("password")
	session, err := mgo.Dial("127.0.0.1:27017")
	if err != nil {
		panic("----------:-(--Error in connecting databases------------------:-(--------")
	} else {
		fmt.Println("------------------------>Database is connected<----------------------")
	}
	mapDo := make(map[string]interface{})
	fmt.Println("email: ", email)
	fmt.Println("password: ", password)
	c := session.DB("school1").C("student2")
	err = c.Find(bson.M{"email": email, "pass": password}).One(&user)
	if err == nil {
		mapDo["status"] = "sucess"
	} else {
		mapDo["status"] = "not sucess"
	}
	v, err1 := template.ParseFiles("profile.html")
	if err1 != nil {
		fmt.Println(err)

	}
	fmt.Println("name", user.Fname, " ", user.Sname, "E-mail", user.Email, "Dp", user.Dp)
	args := make(map[string]string)
	args["Email"] = user.Email
	args["Fname"] = user.Fname
	args["Dp"] = user.Dp
	v.Execute(r, args)
}
func updateHandler(res http.ResponseWriter, req *http.Request) {
	email := req.FormValue("email")
	pass1 := req.FormValue("password1")
	pass2 := req.FormValue("password2")
	mapDo := make(map[string]interface{})
	session, err := mgo.Dial("127.0.0.1:27017")
	if err != nil {
		panic("----------:-(--Error in connecting databases------------------:-(--------")
	} else {
		fmt.Println("------------------------>Database is connected<----------------------")
	}
	dbconn := session.DB("school1").C("student2")
	err = dbconn.Update(bson.M{"email": email}, bson.M{"$set": bson.M{"pass": pass1}})
	if err != nil {
		mapDo["status"] = "not sucess"
	} else {
		mapDo["status"] = "sucessfully Updated "
	}
	fmt.Println(pass2)
	v, _ := template.ParseFiles("cpass.html")
	v.Execute(res, mapDo)
}
func removeHandler(res http.ResponseWriter, req *http.Request) {
	email := req.URL.Path[len("/deactivate/"):]
	mapDo := make(map[string]interface{})
	session, err := mgo.Dial("127.0.0.1:27017")
	if err != nil {
		panic("----------:-(--Error in connecting databases------------------:-(--------")
	} else {
		fmt.Println("------------------------>Database is connected<----------------------")
	}
	dbconn := session.DB("school1").C("student2")
	err = dbconn.Remove(bson.M{"email": email})
	if err != nil {
		mapDo["status"] = "not sucess"
	} else {
		mapDo["status"] = "sucessfully Removed"
	}
	fmt.Fprintf(res, "%s", mapDo["status"])
}

func noDirListing(next http.Handler) http.HandlerFunc {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if f, _ := os.Stat("a/" + r.URL.Path); f.IsDir() && r.URL.Path != "/" {
			fmt.Fprintf(w, "Directory listing not allowed")
			return
		}
		next.ServeHTTP(w, r)
	})
}

func main() {
	s := &File{Title: "file1", Content: []byte("helllo world")}
	s.fopen()
	//byte array
	fmt.Println(fread("file1"))
	//for normal output
	v, _ := fread("file1")
	fmt.Println(String(v))
	mux := http.NewServeMux()
	mux.HandleFunc("/view/", viewHandler)
	mux.HandleFunc("/edit/", EditHandler)
	mux.HandleFunc("/save/", saveHandler)
	mux.HandleFunc("/login/", loginHandler)
	mux.HandleFunc("/home/", homeHandler)
	mux.HandleFunc("/deactivate/", removeHandler)
	mux.HandleFunc("/update/", updateHandler)
	//mux.HandleFunc("/assets", notFound)
	//mux.Handle("/a/", http.StripPrefix("/a/", http.FileServer(http.Dir("a"))))
	mux.Handle("/", noDirListing(http.FileServer(http.Dir("a"))))
	http.ListenAndServe(":4444", mux)
}
