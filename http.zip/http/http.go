<!DOCTYPE html>
<html>
<head>
<title>NJ testing</title>
<meta name='viewport' content='width=device-width'>
<meta name='author' content='R.Nagaraj'/>
<style>
.div{
background-image:url('file:///home/ard-08/go_ws/src/njTest/file/photo.jpg');
}
@media only screen and (max-width:770px){
.div{
  width:500px !important;
  background-image:url('photo.jpg');
  }
}
</style>
</head>
<body style='background-color:#eee;color:#444;'>
<h1>Welcome To MY W0RLD</h1>
<div class='div' style='
background-color:#4e4e4e !important;
color:#e1e1e1 !important;
box-shadow:5px 5px 10px #333,-5px -5px 10px #333;
height:500px;
width:1000px;
margin-left:auto !important;
margin-right:auto !important;
text-align:center;
'></div>
<div>
<h1>You Requested File is <u>{{.Title}}</u></h1></div>
<div>RESULT IS <solid>{{ printf "%s" .Content}}</solid></div>
</div>
</body>
</html>
